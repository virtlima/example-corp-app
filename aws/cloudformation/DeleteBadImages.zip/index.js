var mysql = require('mysql');

var connection = mysql.createConnection({
    host     : process.env.endpoint,
    user     : process.env.user,
    password : process.env.password,
    database : process.env.database
});

connection.connect();

exports.handler = function(event, context) {

    var message = event.Records[0].Sns.Message;
    console.log('Message received from SNS:', message); 
    
    var sql = "DELETE images, active_storage_blobs FROM images,active_storage_blobs WHERE images.id = active_storage_blobs.id AND active_storage_blobs.content_type NOT LIKE 'image/%'";

    connection.query(sql, function(err, results) { 
        if (err){
            console.log(sql);
            console.log("ERROR");
            console.log(err);
            return;
        }
        console.log("Rows Deleted:", results.affectedRows);
        context.succeed('Success');
    });
  
};
